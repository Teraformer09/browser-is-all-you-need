This bundle is reconstructed from the Prime evaluations API (samples + saved logs + inline screenshots).
Prime stores the original evidence.zip in a private artifact store with no public download URL.
Included: hosted_verdict.json, all saved_logs (checkpoints, provenance, installed_apk, recording.json), and all inline per-step screenshots.
Not included (remote-only on Prime): per-frame ui.xml/database.sqlite bytes and the screen-recording.mp4.
Evaluation: https://app.primeintellect.ai/dashboard/evaluations/eaur3i6zlwhydqs3s5l8w3c1
